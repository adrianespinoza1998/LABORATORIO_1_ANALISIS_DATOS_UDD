# Bitácora de decisiones

## Selección y auditoría (RA1)
- Estudio elegido y justificación (tamaño, variables, período, relevancia).
- DQR: faltantes, outliers, codificaciones, riesgos/sesgos.

## ETL (RA2)
- Imputaciones aplicadas y motivo.
- Estandarizaciones (fechas, unidades, categorías).
- Variables derivadas (p. ej., `age_group`).

## EDA (RA2)
- Figuras generadas (ruta en `reports/figures/`) y 3 insights.

## Reproducibilidad (RA5)
- Cómo ejecutar (orden de notebooks), dependencias y versiones.
